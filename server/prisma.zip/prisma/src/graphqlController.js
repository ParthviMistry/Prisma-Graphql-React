import { graphqlHTTP } from "express-graphql";
import { buildSchema } from "graphql";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const schema = buildSchema(`
type Query {
    getAllUsers: [Users]
    getUser: Users
}
type Mutation {
    createUser(name: String, email: String!,  password: String!) : Users
    loginUser(email: String!, password: String!): Users
}
type Users {
    id: Int,
    name: String
    email: String
}
`);

const rootResolvers = {
  getAllUsers: prisma.user.findMany(),
  getUser: async (args, req) => {
    return await prisma.user.findFirst({
      where: {
        id: req.loggedUser.id,
      },
    });
  },
};

export const graphql = graphqlHTTP({
  schema,
  rootValue: rootResolvers,
  graphiql: true, // this creates the interactive GraphQL API explorer with documentation.
});

// module.exports = graphql;
